package org.example;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

class TeamTest {
    //Interface-based model, initialization of variables
    Set<String> test1Interface=new HashSet<>(List.of("apple", "banana", "cherry"));
    Set<String> test2Interface=new HashSet<>(List.of("cherry", "date", "elderberry"));
    Set<String> resultInterface=new HashSet<>(List.of("apple", "banana", "date", "elderberry"));

    //Base-Choice
    @Test
    void interfaceFF()
    {
        Assertions.assertEquals(resultInterface,Team.notInBothTeams(test1Interface,test2Interface));
    }

    //Variations
    @Test
    void interfaceTF()
    {
        Assertions.assertThrows(NullPointerException.class,()->Team.notInBothTeams(null,test2Interface),"test1 is null");
    }

    @Test
    void interfaceFT()
    {
        Assertions.assertThrows(NullPointerException.class,()->Team.notInBothTeams(test1Interface,null),"test2 is null");
    }

    // Functionality-based model, initialization of vairables
    Set<String> team1FunctionalitySmall=new HashSet<>(List.of("apple", "banana", "orange"));
    Set<String> team2FunctionalitySmall=new HashSet<>(List.of("banana"));
    Set<String> resultFunctionalitySmall=new HashSet<>(List.of("apple", "orange"));


    Set<String> team1FunctionalityMedium=new HashSet<>(List.of("apple", "banana", "orange", "pear", "grape"));
    Set<String> team2FunctionalityMedium=new HashSet<>(List.of("pear", "kiwi", "grapefruit", "banana", "peach"));
    Set<String> resultFunctionalityMedium=new HashSet<>(List.of("apple", "orange", "grape", "kiwi", "grapefruit", "peach"));

    Set<String> team1FunctionalityLarge=new HashSet<>(List.of("apple", "banana", "cherry", "date", "elderberry", "fig", "grape", "honeydew", "indian gooseberry", "jackfruit", "kiwi", "lemon", "mango", "nectarine", "orange", "pear", "quince", "raspberry", "strawberry", "tangerine", "ugli fruit", "vanilla bean", "watermelon", "xigua", "yellow passionfruit", "zucchini"));
    Set<String> team2FunctionalityLarge=new HashSet<>(List.of("apricot", "blueberry", "cherry", "dragonfruit", "elderberry", "fig", "grapefruit", "honeydew", "indian gooseberry", "jujube", "kiwi", "lime", "mango", "nectarine", "orange", "pineapple", "quince", "raspberry", "strawberry", "tangerine", "ugli fruit", "vanilla bean", "watermelon", "xigua", "yellow passionfruit", "zucchini"));
    Set<String> resultFunctionalityLarge=new HashSet<>(List.of("date", "banana", "blueberry", "lime", "grape", "dragonfruit", "jackfruit", "apricot", "apple", "lemon", "pear", "pineapple", "grapefruit", "jujube"));

    // Base-Choice
    @Test
    void functionalityTFF()
    {
        Assertions.assertEquals(resultFunctionalitySmall,Team.notInBothTeams(team1FunctionalitySmall,team2FunctionalitySmall));
    }

    //Variations
    @Test

    void functionalityFTF()
    {
        Assertions.assertEquals(resultFunctionalityMedium,Team.notInBothTeams(team1FunctionalityMedium,team2FunctionalityMedium));
    }

    @Test
    void functionalityFFT()
    {
        Assertions.assertEquals(resultFunctionalityLarge,Team.notInBothTeams(team1FunctionalityLarge,team2FunctionalityLarge));
    }
}