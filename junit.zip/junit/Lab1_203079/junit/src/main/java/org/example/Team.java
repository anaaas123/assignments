package org.example;

import java.util.HashSet;
import java.util.Set;

public class Team {
    public static Set<String> notInBothTeams(Set<String> team1, Set<String> team2)
    {
        if(team1==null)
            throw new NullPointerException("team1 is null");
        if(team2==null)
            throw new NullPointerException("team2 is null");
        Set<String> result = new HashSet<String>();
        for (String s : team1) {
            if (!team2.contains(s)) {
                result.add(s);
            }
        }
        for (String s : team2) {
            if (!team1.contains(s)) {
                result.add(s);
            }
        }
        return result;
    }
}